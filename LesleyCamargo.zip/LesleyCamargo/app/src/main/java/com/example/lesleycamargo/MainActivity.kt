package com.example.lesleycamargo


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.lesleycamargo.ui.theme.LesleyCamargoTheme

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.border




class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LesleyCamargoTheme() {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MessageCard(Message("Android", "Jetpack Compose"))

                }
            }
        }
    }
}
@Preview
@Composable
fun PreviewMessageCard() {
    LesleyCamargoTheme() {
        Surface {
            MessageCard(
                msg = Message("Diego", "Take a look at Jetpack Compose, it's great!")
            )
        }
    }
}

@Composable
fun MessageCard(name:String){
    Text("Hello $name!")
}
/*@Preview(showBackground = true)
@Composable
fun MessageCardPreview(){
    MessageCard(name = "Lesley")
}*/


data class Message(val author: String, val body: String)
@Composable
fun MessageCard(msg: Message){
    Row(modifier = Modifier.padding(all = 8.dp)) {

        Image(
            painter = painterResource(R.drawable.profile_picture),
            contentDescription = "Contact profile picture",

        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .border(
                1.5.dp, androidx.compose.material3.MaterialTheme.colorScheme.secondary,
                CircleShape
            )


        )


        Spacer(modifier = Modifier.width(8.dp))

        Column {
            Text(
                text = msg.author,
                color = MaterialTheme.colorScheme.secondary,
                style = MaterialTheme.typography.

            )
            Spacer(modifier = Modifier.height(4.dp))

            Text(text = msg.body,
                style = MaterialTheme.typography.body2
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MessageCardPreview(){
    MessageCard(msg = Message("Lesley Camargo",
        "Welcome!"))
}



